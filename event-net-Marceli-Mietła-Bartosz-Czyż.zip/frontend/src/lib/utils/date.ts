export const createDate = (date: Date, time: string): Date => {
    const [hours, minutes] = time.split(':').map(Number);
    const newDate = new Date(date);
    newDate.setHours(hours, minutes, 0, 0); // Set hours and minutes, reset seconds and milliseconds
    return newDate;
}