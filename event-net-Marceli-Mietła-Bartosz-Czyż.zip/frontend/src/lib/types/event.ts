export interface EventCard {
    id: number;
    name: string;
    start_datetime: string;
    date: Date;
    time: string;
    keywords: string[];
}